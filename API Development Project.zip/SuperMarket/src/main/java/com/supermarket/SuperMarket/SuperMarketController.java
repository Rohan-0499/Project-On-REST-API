package com.supermarket.SuperMarket;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("api")
//@CrossOrigin("http://localhost:8080")
public class SuperMarketController {
	@Autowired
	SessionFactory factory;
	
	@GetMapping("categories")
	List<Category> allCategory()
	{
		Session session = factory.openSession();
		List<Category> arraylist =session.createCriteria(Category.class).list();
		return arraylist;
	}
	@GetMapping("product")
	List<Product> allProduct()
	{
		Session session = factory.openSession();
		List<Product> arraylist =session.createCriteria(Product.class).list();
		return arraylist;
	}
	@GetMapping("category/{id}")
	public Category getCategory(@PathVariable int id)
	{
		Session session= factory.openSession();
		Category category= session.load(Category.class, id);
		return category;
	}
	
	@GetMapping("product/{id}")
	public Product getProduct(@PathVariable int id)
	{
		Session session= factory.openSession();
		Product product=session.load(Product.class, id);
		return product;
		
	}
	@PostMapping("categories")
	public List<Category> addCategory(@RequestBody Category category)
	{
		Session session =factory.openSession();
		Transaction tx =session.beginTransaction();
		session.save(category);
		tx.commit();
		List<Category> list= allCategory();
		return list;
	}
	@PostMapping("products")
	public List<Product> addProduct(@RequestBody Product product)
	{
		Session session =factory.openSession();
		Transaction tx =session.beginTransaction();
		session.save(product);
		tx.commit();
		List<Product> list= allProduct();
		return list;
	}
	@DeleteMapping("categories/{categoryid}")
	public List<Category> deleteCategory(@PathVariable int categoryid )
	{
		Session session = factory.openSession();
		Category category = session.load(Category.class, categoryid);
		Transaction tx = session.beginTransaction();
		session.delete(category);
		tx.commit();
		List<Category> list =allCategory();
		return list;
	}
	@DeleteMapping("products/{productid}")
	public List<Product> deleteProduct(@PathVariable int productid )
	{
		Session session = factory.openSession();
		Product product = session.load(Product.class, productid);
		Transaction tx = session.beginTransaction();
		session.delete(product);
		tx.commit();
		List<Product> list =allProduct();
		return list;
	}
	@PutMapping("category")
	public List<Category> updateCategory(@RequestBody Category client)
	{
			
			Session session = factory.openSession();

			Transaction tx = session.beginTransaction();

			session.saveOrUpdate(client);

			tx.commit();

			List<Category> list = allCategory();

			return list;
	}
	@PutMapping("product")
	public List<Product> updateCategory(@RequestBody Product client)
	{
			
			Session session = factory.openSession();

			Transaction tx = session.beginTransaction();

			session.saveOrUpdate(client);

			tx.commit();

			List<Product> list = allProduct();

			return list;
	}


}
