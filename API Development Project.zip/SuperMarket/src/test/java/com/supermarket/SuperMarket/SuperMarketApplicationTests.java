package com.supermarket.SuperMarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
